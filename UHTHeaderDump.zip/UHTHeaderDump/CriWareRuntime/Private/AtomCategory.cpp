#include "AtomCategory.h"

UAtomCategory::UAtomCategory() {
}

void UAtomCategory::SetVolumeByName(const FString& CategoryName, float Volume) {
}

void UAtomCategory::SetAisacControlByName(const FString& CategoryName, const FString& AisacName, float value) {
}

void UAtomCategory::PauseByName(const FString& CategoryName, bool bPause) {
}

bool UAtomCategory::IsPausedByName(const FString& CategoryName) {
    return false;
}

float UAtomCategory::GetVolumeByName(const FString& CategoryName) {
    return 0.0f;
}


